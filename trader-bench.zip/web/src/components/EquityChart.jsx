import React from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts'

export default function EquityChart({ equity, spyUSD }) {
  const fmt = (d) => new Date(d).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})
  // Merge by timestamp
  const map = new Map()
  for (const p of equity || []) {
    map.set(p.ts, { ts: p.ts, equity: p.value })
  }
  for (const p of spyUSD || []) {
    const row = map.get(p.ts) || { ts: p.ts }
    row.spyUSD = p.value
    map.set(p.ts, row)
  }
  const data = Array.from(map.values()).sort((a,b)=>new Date(a.ts)-new Date(b.ts))
  return (
    <div className="card h-85">
      <div className="text-sm muted">Portfolio Value vs. SPY (USD equivalent)</div>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="ts" tickFormatter={fmt} minTickGap={40} />
          <YAxis domain={['auto', 'auto']} />
          <Tooltip labelFormatter={(v) => new Date(v).toLocaleString()} />
          <Legend />
          <Line type="monotone" dataKey="equity" stroke="#2563eb" name="Equity" dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="spyUSD" stroke="#16a34a" name="SPY (USD equiv.)" dot={false} strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
